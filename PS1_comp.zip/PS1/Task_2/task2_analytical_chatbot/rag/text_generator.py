# Converting the trend data into natural language explanations :
import pandas as pd


def generate_trend_text(df, company_name):
    texts = []

    for _, row in df.iterrows():
        # Skip invalid dates safely
        if pd.isna(row["Date"]):
            continue

        date = row["Date"].strftime("%Y-%m-%d")
        close_price = round(float(row["Close"]), 2)

        day_trend = "rose" if row["up_day"] else "fell"
        week_trend = "rose" if row["up_week"] else "fell"

        text = (
            f"On {date}, {company_name} stock closed at {close_price} USD. "
            f"The stock {day_trend} compared to the previous day and "
            f"{week_trend} compared to the previous week."
        )

        texts.append(text)

    return texts
