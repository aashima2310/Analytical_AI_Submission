from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

# Creating the documnets :

def create_documents(texts, source_name):
    documents = []
    for text in texts:
        documents.append(
            Document(
                page_content=text,
                metadata={
        "source": source_name,
        "ticker": source_name  
    }
            )
        )
    return documents

# Chunking of the documents :

def chunk_documents(documents):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=300,
        chunk_overlap=50
    )
    return splitter.split_documents(documents)

# Creation of vector database

def create_vector_db(chunks, persist_dir="chroma_db"):
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vector_db = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=persist_dir
    )

    vector_db.persist()
    return vector_db
