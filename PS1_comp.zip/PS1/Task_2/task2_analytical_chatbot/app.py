import os

from trends import load_and_prepare_data
from rag.text_generator import generate_trend_text
from rag.vector_store import (
    create_documents,
    chunk_documents,
    create_vector_db
)

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser


# STEP 1: INGESTION


def ingest_data():
    tickers = {
        "AAPL": "Apple",
        "MSFT": "Microsoft",
        "TSLA": "Tesla"
    }

    all_docs = []

    for ticker, name in tickers.items():
        df = load_and_prepare_data(ticker)
        texts = generate_trend_text(df, name)

        # IMPORTANT: pass ticker as metadata
        docs = create_documents(texts, ticker)
        all_docs.extend(docs)

    chunks = chunk_documents(all_docs)
    create_vector_db(chunks)

    print("✅ Vector DB created successfully")


# STEP 2: LOAD VECTOR DB


def load_vector_db():
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    return Chroma(
        persist_directory="chroma_db",
        embedding_function=embeddings
    )


# QUERY UNDERSTANDING

def detect_ticker(query):
    q = query.lower()
    if "apple" in q:
        return "AAPL"
    if "microsoft" in q:
        return "MSFT"
    if "tesla" in q:
        return "TSLA"
    return None


def detect_intent(query):
    q = query.lower()
    if "why" in q:
        return "WHY"
    if "when" in q:
        return "WHEN"
    if "up" in q or "rise" in q:
        return "UP"
    if "down" in q or "fell" in q or "drop" in q:
        return "DOWN"
    return "GENERAL"


# ASK QUESTION


def ask_question(vectordb, query):
    ticker = detect_ticker(query)
    intent = detect_intent(query)

    docs = vectordb.similarity_search(
        query,
        k=5,
        filter={"source": ticker} if ticker else None
    )

    context = "\n".join(doc.page_content for doc in docs)

    llm = ChatGroq(
        model="llama-3.1-8b-instant",
        temperature=0,
        groq_api_key="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"
 )

    prompt = PromptTemplate(
        input_variables=["context", "question", "intent"],
        template="""
You are a financial market analyst.

Intent: {intent}

Use the data below to answer clearly and logically.
If the data does not explain the question, say so honestly.

Data:
{context}

Question:
{question}

Answer:
"""
    )

    chain = prompt | llm | StrOutputParser()

    return chain.invoke({
        "context": context,
        "question": query,
        "intent": intent
    })



# MAIN APP


def main():
    # RUN ONLY ONCE, THEN COMMENT THIS
    # ingest_data()

    vectordb = load_vector_db()

    print("\n📈 Analytical Stock Chatbot Ready")
    print("Type 'exit' to quit\n")

    while True:
        q = input("Ask your question: ")
        if q.lower() == "exit":
            break

        answer = ask_question(vectordb, q)
        print("\nAnswer:\n", answer)


if __name__ == "__main__":
    main()
