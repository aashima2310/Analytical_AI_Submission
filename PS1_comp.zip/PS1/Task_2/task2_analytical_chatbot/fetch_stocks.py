import yfinance as yf
import os

def fetch_stock_data():
    stocks = ["AAPL", "MSFT", "TSLA"]
    os.makedirs("data", exist_ok=True)

    for ticker in stocks:
        df = yf.download(ticker, start="2022-01-01", end="2025-01-01")
        df.reset_index(inplace=True)

        file_path = f"data/{ticker}.csv"
        df.to_csv(file_path, index=False)
        print(f"Saved {ticker} data to {file_path}")
