
#  Analytical Stock Chatbot (RAG-Based)
# Analytical Chatbot for Stock Market Insights

# Overview

This project is a Natural Language Interface for Stock Market Analysis.
It allows users to ask plain English questions about stock movements and receive context-aware answers by analyzing historical stock data and correlating trends with events.

The system identifies company tickers automatically, analyzes price trends, and explains why and when stock movements occurred.
---
# Objectives

-Enable natural language querying over stock market datasets
-Automatically identify stock tickers from user questions
-Perform trend analysis (price rise, fall, peaks, drops)
-Provide contextual explanations behind market movements

##  Architecture
- Data Ingestion → Stock CSV processing
- Text Generation → Financial trend summaries
- Vector Database → ChromaDB with embeddings
- Retrieval → Semantic similarity search
- LLM Reasoning → Groq LLaMA model
- Interface → CLI-based chatbot

---

##  Technologies Used
- Python
- LangChain
- ChromaDB
- HuggingFace Embeddings
- Groq LLM (LLaMA)
- Pandas, NumPy

---

##  How It Works
1. Stock data is loaded and converted into textual trends
2. Text is chunked and embedded
3. Embeddings are stored in a vector database
4. User query → intent + ticker detection
5. Relevant context retrieved
6. LLM generates a contextual answer

## ▶️ How to Run

Create virtual environment :
-python -m venv venv
-.\venv\Scripts\activate
-add install requirements2.txt
-run app.py


#### SAMPLE QUESTIONS
 
### Ask your question: when did apple stock grew?

Answer:
 Based on historical data, Apple's stock price has experienced significant growth over the years. 

One notable period of growth was during the 2003-2006 period, when Apple's stock price increased from around $4 to $200, largely due to the success of the iPod and the introduction of the iPhone in 2007.

However, the most significant growth period for Apple's stock price occurred between 2009 and 2021, when the stock price increased from around $8 to over $180. This growth was driven by the success of the iPhone, as well as the company's expansion into new markets such as wearables and services.

#### Ask your question: why and when did tesla stock fell?

Answer:
 Based on historical data, I can provide some insights on why and when Tesla's stock price fell. However, please note that the stock market is highly volatile, and multiple factors can contribute to a stock's price movement.

From my analysis, I found that Tesla's stock price has experienced several significant declines over the years. Here are a few notable instances:

1. **January 2022:** Tesla's stock price fell by around 65% from its peak of $1,222.09 on November 4, 2021, to $423.19 on January 4, 2022. This decline was largely due to a combination of factors, including:
        * Rising interest rates, which increased the cost of borrowing and reduced demand for Tesla's products.
        * Concerns about the company's valuation, with some analysts questioning whether Tesla's stock price was overvalued.
        * Supply chain disruptions and production issues, which affected the company's ability to meet demand.
2. **July 2022:** Tesla's stock price fell by around 20% from $724.94 on June 16, 2022, to $579.19 on July 25, 2022. This decline was largely due to:
        * Concerns about the company's ability to meet demand, particularly in the face of supply chain disruptions and production issues.
        * Rising competition from other electric vehicle manufacturers, such as Rivian and Lucid Motors.
        * A decline in the overall market, with the S&P 500 index falling by around 10% over the same period.
3. **October 2022:** Tesla's stock price fell by around 15% from $384.99 on September 30, 2022, to $326.69 on October 24, 2022. This decline was largely due to:
        * Concerns about the company's ability to meet demand, particularly in the face of supply chain disruptions and pro        * A decline in the overall market, with the S&P 500 index falling by around 10% over the same period.
        * A reduction in the company's production guidance, which raised concerns about its ability to meet demand.        

It's worth noting that these are just a few examples of when Tesla's stock price fell, and there may be other instances where the stock price declined due to various factors. Additionally, the stock market is highly volatile, and prices can fluctuate rapidly in response to changing market conditions.

In summary, Tesla's stock price fell due to a combination of factors, including rising interest rates, concerns about the company's valuation, supply chain disruptions, production issues, competition from other electric vehicle manufacturers, and a decline in the overall market.

-----