import pandas as pd


def load_and_prepare_data(ticker):
    df = pd.read_csv(f"data/{ticker}.csv")

    # Ensure Date is datetime
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")

    # Sort and RESET index (CRITICAL)
    df = df.sort_values("Date").reset_index(drop=True)

    # Previous values
    df["Prev_Day_Close"] = df["Close"].shift(1)
    df["Prev_Week_Close"] = df["Close"].shift(5)

    # Trends
    df["up_day"] = df["Close"] > df["Prev_Day_Close"]
    df["up_week"] = df["Close"] > df["Prev_Week_Close"]

    # Fill ONLY non-date columns
    df["Prev_Day_Close"] = df["Prev_Day_Close"].fillna(0)
    df["Prev_Week_Close"] = df["Prev_Week_Close"].fillna(0)
    df["up_day"] = df["up_day"].fillna(False)
    df["up_week"] = df["up_week"].fillna(False)

    return df
