#  Task 1: Predictive Core – Static Time Series Forecasting

##  Project Overview
This project implements a **time series forecasting engine** for stock prices using historical market data.  
The objective is not only to predict future prices but also to **model uncertainty and volatility**, which are inherent in financial markets.

The model is built using a **Long Short-Term Memory (LSTM)** neural network and forecasts stock prices for the **next 7 business days**, along with **confidence intervals**.

---

##  Problem Statement (Task 1)
**Goal:**  
Develop a predictive core that learns from historical stock data to forecast future trends.

**Input:**  
- Daily OHLCV stock data (Yahoo Finance)
- Example ticker used: **GE (General Electric)**

**Process:**  
- Feature engineering (returns, volatility)
- Time-series windowing
- LSTM-based sequence modeling
- Volatility-based uncertainty estimation

**Output:**  
- Historical trend visualization  
- 7-day future price forecast  
- Shaded confidence interval (risk & uncertainty)  
- Model evaluation metrics  

---

## 🧠 Methodology

### 1. Data Collection
- Stock data downloaded using `yfinance`
- Date range: **2021 – 2026**
- Frequency: Daily (business days)

### 2. Feature Engineering
- Daily Returns
- Rolling Volatility (20-day standard deviation)
- Volume
- Close Price

### 3. Data Preparation
- Train/Test split (80% / 20%)
- Feature scaling using MinMaxScaler
- Sliding window approach (30-day lookback)

### 4. Model Architecture
- Single-layer LSTM (50 units)
- Dropout for regularization
- Dense output layer
- Optimizer: Adam
- Loss function: Mean Squared Error (MSE)

### 5. Forecasting Strategy
- Recursive multi-step forecasting
- Predicts next 7 business days
- Uses rolling window updates

### 6. Uncertainty Modeling
- Confidence intervals calculated using recent volatility
- 95% confidence band plotted around forecasts

---

##  Results & Visualizations
- Historical price trend
- Rolling volatility plot
- Training vs Validation loss
- 7-day forecast plot
- Forecast with confidence intervals

---

##  Evaluation Metrics
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- Mean Absolute Percentage Error (MAPE)

Metrics are calculated on validation data to assess model accuracy.

---

##  Technologies Used
- Python
- Pandas, NumPy
- Matplotlib
- Scikit-learn
- TensorFlow / Keras
- yfinance

---

##  Future Improvements
- Transformer-based time series models
- Multi-ticker support
- Probabilistic forecasting
- Real-time data integration
- Interactive dashboards


